# Fingerprint DT/BOOT freeze — stage gate, not a command to flash

**Default: zero boot writes, zero DTB/DTBO writes.** This handset historically already registered `QBT2000`; a missing TEE/HAL is not an instruction to modify device tree.

Before approving a fingerprint BOOT candidate, require all checked:

- [ ] Current live model/codename, kernel, BOOT slot layout, PIT/by-name targets and actual capacities verified. No generic fastboot, no unverified remembered partition path.
- [ ] Known-good actual boot backed up on handset + host in two independent locations; SHA-256 verified, restoration method tested with TWRP ADB and owner approval.
- [ ] Evidence showing a kernel-only issue rather than TEE/HAL gap; userspace solution attempted/ruled out.
- [ ] Fingerprint branch makes **no** DTS/DTSI/DTBO edits; baseline vs candidate DT hashes and layout byte-identical; no DT overlay index reinterpretation.
- [ ] Candidate boot header and address fields cloned from the current proven donor, not from generic Samsung defaults; raw ARM64 `Image`, correct legacy v1 page size, ramdisk/init and kernel command line verified.
- [ ] Candidate byte length fits the live BOOT partition with ample margin; no silent truncation; `verify-boot-image.py` passes with current partition bytes. Historical bad gzip payload and ~57.8-MB image are explicitly rejected.
- [ ] Preflash manifest names exact verified BOOT target, SHA of donor/candidate, rootfs/SYSTEM untouched, restoration artifact and no secret-containing logs.
- [ ] After write, full candidate readback hash matches; Nuxel UI, systemd, PIN and SSH are functional, **not** simply a reboot to TWRP.
- [ ] Any TWRP return triggers evidence collection and verified known-good restore immediately; identical bad candidate never reflashed.

Historical incident source: `evidence/bootloop-0023-20261114-1002/FIX-REPORT.md`. For the original incident the report cites raw `Image` and donor `dt_size=1`, historical BOOT partition 57,671,680 bytes. **These numbers are evidence of that incident, not authorized constants for future flashes.**
