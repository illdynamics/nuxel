# NUXEL QBT2000 / 10: FINAL REPORT AND HANDOFF

**Recommended executor:** DeepSeek Flash / fast documentation+release model (no physical flash)

**Mission:** Create a final, non-inflated engineering report and reproducible follow-up with precise blockers or proof of actual operation.

## Non-negotiable contract — read this before acting
- Device scope: only the owner-approved Samsung Galaxy S10+ SM-G975F `beyond2lte`, Exynos9820, Nuxel/Fedora 43, historical Samsung/Linux4 downstream 4.14.253. **Re-identify the physical device, boot, and source hashes before changing anything.** The ZIP is not proof of what is installed live.
- Preserve PIN/password/pattern unlock and the working phone. No fake enroll/match, no browser-simulated sensor evidence, no fabricated sensor, no templates/images/raw biometric data, no forged TEE attestation, no bypassing secure-boot, signed-TA checks, RPMB, TEE keys, or credential verification.
- **DT freeze by default:** no DTB, DTBO, dts, dtsi, reserved-memory, pinctrl, clocks, GPIO, power-rail or boot-header changes for this fingerprint mission. If hard evidence independently proves a DT change necessary, STOP and produce a separate evidence-based change request and rollback design for the owner; never quietly combine it with a fingerprint fix.
- Work in an isolated branch/worktree. Start with read-only commands; use host tests and reversible userspace changes before considering any device image. No blind `dd`, no generic `fastboot`, no guesses about partitions, no EFS/IMEI/NV/RPMB/calibration, no touch of modem, keys or user data. Never paste secrets into reports.
- Label every conclusion `PROVED_LIVE`, `HISTORICAL_LIVE`, `PRESENT_IN_ZIP`, `PROVED_IN_PINNED_SOURCE`, `UPSTREAM_CONCEPT_ONLY`, `INFERRED`, or `UNKNOWN`. Tie real tests to timestamp, boot/kernel hash, device identity, and captured redacted evidence. Unit mocks are not a hardware PASS.
- A flash is **conditional**, not an expected step. The established QBT2000 device nodes suggest the kernel already binds it. Never rewrite/flash the kernel just to feel progress. Use the historical `evidence/bootloop-0023-20261114-1002/FIX-REPORT.md` and `tools/s10plus/verify-boot-image.py` gates if a real flash becomes necessary.
- TWRP agreement: if a candidate reboots back to TWRP, it FAILED. Collect logs, compare candidate vs known-good, determine first failing stage, then restore verified known-good BOOT to boot Nuxel before any further experiment. Do not repeat the same failed image. A revised image may be retried only after correcting the demonstrated cause and passing all offline checks. Never spin indefinitely; if safe restoration is impossible, STOP and report precise recovery blockage.
- Avoid external artifact provenance mistakes: an example LineageOS `beyond1lte` TEE file is not proven compatible with this `beyond2lte` unit; inventory official owner-extracted matching builds, license and dependency hashes without distributing protected binaries.
- Treat technical blockers as explicit branch conditions. If the lawful signed TA/secure runtime cannot be demonstrated, finish all safe hardening, truthful status reporting, and a precise blocker manifest. Never claim genuine fingerprint functionality before owner-performed physical enrollment/verification and secure authentication tests pass.
- Primary historical inputs to inspect: `hw/NUXEL_02_QBT2000_FINGERPRINT_STANDALONE.md`, `diagnostics/pwnage-91000/hardware/fingerprint-live.txt`, `services/nuxel-bridge/src/{fingerprint_provider.py,security_provider.py,api.py}`, `pwa/nuxel-apps/settings/{index.html,pwange45000-settings.js}`, `pwa/nuxel-home/js/lockscreen-auth.js`, `tools/a80/fingerprint-enroll.py`, `configs/nuxel/security/biometric-unlock.json`, `device/s10plus/deviceinfo`, `evidence/bootloop-0023-20261114-1002/FIX-REPORT.md`. The uploaded ZIP DOES NOT contain `pwn/finger*.md`, `reports/REPORT-FINGERPRINT.md` or `packs/finger/`; look for these in the *actual* live repository and flag them missing if unavailable.

## Execute, in this order

1. Collect and read receipts 01–09, repo diff, tests, hash inventory, exact active boot/DT, deployed Python/JS/daemon hashes, owner test receipts, and vendor compatibility matrix.
2. Produce `reports/FINGERPRINT-ENDGAME-SECURITY.md` and update relevant README, CHANGELOG/feature matrix and code comments. Distinguish kernel node, TA health, hardware enrollment, actual match, lockscreen unlock, reboot persistence and secure deletion. State both progress percentage estimate and `physical verified` boolean transparently.
3. If secure provider is blocked, publish a concrete, owner-actionable blocker manifest naming the exact missing signed artifact or ABI/provenance requirement—not a promise that DeepSeek will invent it. Ensure Settings remains disabled/truthful and PIN intact.
4. Provide a file-by-file changed inventory, security review, tested build steps, PASS/FAIL/SKIP/NOT_TESTED, exact rollback strategy, developer handoff prompt and source URLs. Do not embed vendor private binaries, fingerprint material, keys or local bridge tokens in release artifacts.
5. If a valid git worktree exists, commit logically grouped source/test/docs changes on a feature branch only after the owner-approved workflow; do not assume `.git` exists in the ZIP. Publish nothing to external repos without the user's relevant existing instructions and permissions.
6. Require terminal health checks: Nuxel boot, PIN fallback, systemd, SSH, baseline DTB/DTBO unchanged. If a failed candidate is still in TWRP, this phase MUST FAIL and stage 08 takes precedence over any release.


## Mandatory exit artifact and next-phase gate

Deliver final `reports/FINGERPRINT-ENDGAME-SECURITY.md`, `reports/FINGERPRINT-FINAL-EVIDENCE-MATRIX.md`, concise owner-facing outcome, and remaining TODOs. A security blocker with a healthy Nuxel/PIN is a legitimate safe engineering outcome, but it is **not** a working fingerprint scanner.
