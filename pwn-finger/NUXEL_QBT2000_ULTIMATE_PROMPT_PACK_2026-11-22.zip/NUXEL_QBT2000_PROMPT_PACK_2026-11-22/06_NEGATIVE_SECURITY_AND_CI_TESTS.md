# NUXEL QBT2000 / 06: NEGATIVE SECURITY AND CI TESTS

**Recommended executor:** DeepSeek Flash / fast implementation model (CI only)

**Mission:** Create repeatable evidence-driven fingerprint security regressions without falsely converting mock tests into hardware passes.

## Non-negotiable contract — read this before acting
- Device scope: only the owner-approved Samsung Galaxy S10+ SM-G975F `beyond2lte`, Exynos9820, Nuxel/Fedora 43, historical Samsung/Linux4 downstream 4.14.253. **Re-identify the physical device, boot, and source hashes before changing anything.** The ZIP is not proof of what is installed live.
- Preserve PIN/password/pattern unlock and the working phone. No fake enroll/match, no browser-simulated sensor evidence, no fabricated sensor, no templates/images/raw biometric data, no forged TEE attestation, no bypassing secure-boot, signed-TA checks, RPMB, TEE keys, or credential verification.
- **DT freeze by default:** no DTB, DTBO, dts, dtsi, reserved-memory, pinctrl, clocks, GPIO, power-rail or boot-header changes for this fingerprint mission. If hard evidence independently proves a DT change necessary, STOP and produce a separate evidence-based change request and rollback design for the owner; never quietly combine it with a fingerprint fix.
- Work in an isolated branch/worktree. Start with read-only commands; use host tests and reversible userspace changes before considering any device image. No blind `dd`, no generic `fastboot`, no guesses about partitions, no EFS/IMEI/NV/RPMB/calibration, no touch of modem, keys or user data. Never paste secrets into reports.
- Label every conclusion `PROVED_LIVE`, `HISTORICAL_LIVE`, `PRESENT_IN_ZIP`, `PROVED_IN_PINNED_SOURCE`, `UPSTREAM_CONCEPT_ONLY`, `INFERRED`, or `UNKNOWN`. Tie real tests to timestamp, boot/kernel hash, device identity, and captured redacted evidence. Unit mocks are not a hardware PASS.
- A flash is **conditional**, not an expected step. The established QBT2000 device nodes suggest the kernel already binds it. Never rewrite/flash the kernel just to feel progress. Use the historical `evidence/bootloop-0023-20261114-1002/FIX-REPORT.md` and `tools/s10plus/verify-boot-image.py` gates if a real flash becomes necessary.
- TWRP agreement: if a candidate reboots back to TWRP, it FAILED. Collect logs, compare candidate vs known-good, determine first failing stage, then restore verified known-good BOOT to boot Nuxel before any further experiment. Do not repeat the same failed image. A revised image may be retried only after correcting the demonstrated cause and passing all offline checks. Never spin indefinitely; if safe restoration is impossible, STOP and report precise recovery blockage.
- Avoid external artifact provenance mistakes: an example LineageOS `beyond1lte` TEE file is not proven compatible with this `beyond2lte` unit; inventory official owner-extracted matching builds, license and dependency hashes without distributing protected binaries.
- Treat technical blockers as explicit branch conditions. If the lawful signed TA/secure runtime cannot be demonstrated, finish all safe hardening, truthful status reporting, and a precise blocker manifest. Never claim genuine fingerprint functionality before owner-performed physical enrollment/verification and secure authentication tests pass.
- Primary historical inputs to inspect: `hw/NUXEL_02_QBT2000_FINGERPRINT_STANDALONE.md`, `diagnostics/pwnage-91000/hardware/fingerprint-live.txt`, `services/nuxel-bridge/src/{fingerprint_provider.py,security_provider.py,api.py}`, `pwa/nuxel-apps/settings/{index.html,pwange45000-settings.js}`, `pwa/nuxel-home/js/lockscreen-auth.js`, `tools/a80/fingerprint-enroll.py`, `configs/nuxel/security/biometric-unlock.json`, `device/s10plus/deviceinfo`, `evidence/bootloop-0023-20261114-1002/FIX-REPORT.md`. The uploaded ZIP DOES NOT contain `pwn/finger*.md`, `reports/REPORT-FINGERPRINT.md` or `packs/finger/`; look for these in the *actual* live repository and flag them missing if unavailable.

## Execute, in this order

1. Implement isolated unit tests for bridge identity/origin auth and all mutation aliases; denial without secure provider; strict readiness; no metadata masquerading as enrollment; no caller-origin auth result; challenge freshness, one-time use and cancellation; secure slot deletion behavior; PIN continuity.
2. Include negative tests for missing/malformed provider response, crash, timeouts, partial enroll, spoofed status, cold start without the provider, suspend/restart, TEE health drop, locked owner, wrong caller, and wrong sensor. Tests must NEVER emulate success on a real hardware acceptance receipt.
3. Create exact test fixture manifests and environment setup; do not rely on hidden `node_modules` or gitignored build files. Distinguish `PASS`, `FAIL`, `BLOCKED` and `SKIP-MISSING-PREREQ`. On this archive `tests/v086/test_lock_security.py` passes 6/6, but older A80/A84 lock suites show failures/stale assertions and a missing JS dependency; reconcile instead of ignoring.
4. Require static assertions that the new fingerprint branch produces no patch to DTB/DTBO/dts/dtsi or boot-image metadata and includes no TA blobs/template fixtures in public paths. Verify unsupported modes and broker errors fail closed.
5. Run relevant Python/JS syntax checks, unit/contract tests and build reproducibility. Produce a minimal 'safe to deploy userspace' gate. Never run a hardware flash in this phase.


## Mandatory exit artifact and next-phase gate

Deliver `reports/FINGERPRINT-06-TEST-MATRIX.md`, code/test diff, command output and documented SKIPs. A unit test based on mocks may pass without changing `HARDWARE_MATCH_VERIFIED=false`.
