# NUXEL QBT2000 / 09: OWNER PHYSICAL END TO END ACCEPTANCE

**Recommended executor:** DeepSeek V4 Pro Thinking (only after signed secure provider is PROVED)

**Mission:** Validate actual fingerprint enrollment/match/delete on real glass with owner cooperation and full security and operational regression.

## Non-negotiable contract — read this before acting
- Device scope: only the owner-approved Samsung Galaxy S10+ SM-G975F `beyond2lte`, Exynos9820, Nuxel/Fedora 43, historical Samsung/Linux4 downstream 4.14.253. **Re-identify the physical device, boot, and source hashes before changing anything.** The ZIP is not proof of what is installed live.
- Preserve PIN/password/pattern unlock and the working phone. No fake enroll/match, no browser-simulated sensor evidence, no fabricated sensor, no templates/images/raw biometric data, no forged TEE attestation, no bypassing secure-boot, signed-TA checks, RPMB, TEE keys, or credential verification.
- **DT freeze by default:** no DTB, DTBO, dts, dtsi, reserved-memory, pinctrl, clocks, GPIO, power-rail or boot-header changes for this fingerprint mission. If hard evidence independently proves a DT change necessary, STOP and produce a separate evidence-based change request and rollback design for the owner; never quietly combine it with a fingerprint fix.
- Work in an isolated branch/worktree. Start with read-only commands; use host tests and reversible userspace changes before considering any device image. No blind `dd`, no generic `fastboot`, no guesses about partitions, no EFS/IMEI/NV/RPMB/calibration, no touch of modem, keys or user data. Never paste secrets into reports.
- Label every conclusion `PROVED_LIVE`, `HISTORICAL_LIVE`, `PRESENT_IN_ZIP`, `PROVED_IN_PINNED_SOURCE`, `UPSTREAM_CONCEPT_ONLY`, `INFERRED`, or `UNKNOWN`. Tie real tests to timestamp, boot/kernel hash, device identity, and captured redacted evidence. Unit mocks are not a hardware PASS.
- A flash is **conditional**, not an expected step. The established QBT2000 device nodes suggest the kernel already binds it. Never rewrite/flash the kernel just to feel progress. Use the historical `evidence/bootloop-0023-20261114-1002/FIX-REPORT.md` and `tools/s10plus/verify-boot-image.py` gates if a real flash becomes necessary.
- TWRP agreement: if a candidate reboots back to TWRP, it FAILED. Collect logs, compare candidate vs known-good, determine first failing stage, then restore verified known-good BOOT to boot Nuxel before any further experiment. Do not repeat the same failed image. A revised image may be retried only after correcting the demonstrated cause and passing all offline checks. Never spin indefinitely; if safe restoration is impossible, STOP and report precise recovery blockage.
- Avoid external artifact provenance mistakes: an example LineageOS `beyond1lte` TEE file is not proven compatible with this `beyond2lte` unit; inventory official owner-extracted matching builds, license and dependency hashes without distributing protected binaries.
- Treat technical blockers as explicit branch conditions. If the lawful signed TA/secure runtime cannot be demonstrated, finish all safe hardening, truthful status reporting, and a precise blocker manifest. Never claim genuine fingerprint functionality before owner-performed physical enrollment/verification and secure authentication tests pass.
- Primary historical inputs to inspect: `hw/NUXEL_02_QBT2000_FINGERPRINT_STANDALONE.md`, `diagnostics/pwnage-91000/hardware/fingerprint-live.txt`, `services/nuxel-bridge/src/{fingerprint_provider.py,security_provider.py,api.py}`, `pwa/nuxel-apps/settings/{index.html,pwange45000-settings.js}`, `pwa/nuxel-home/js/lockscreen-auth.js`, `tools/a80/fingerprint-enroll.py`, `configs/nuxel/security/biometric-unlock.json`, `device/s10plus/deviceinfo`, `evidence/bootloop-0023-20261114-1002/FIX-REPORT.md`. The uploaded ZIP DOES NOT contain `pwn/finger*.md`, `reports/REPORT-FINGERPRINT.md` or `packs/finger/`; look for these in the *actual* live repository and flag them missing if unavailable.

## Execute, in this order

1. Check stage 03/04 result first. If legitimate signed TEE/TA and secure HAL provider have not been proven, do not ask the user to scan a finger or mark hardware PASS; return `BLOCKED` with exact evidence.
2. Owner personally unlocks using the existing local credential, then enrolls a fresh finger on the physical QBT2000. Capture only state/progress/slot count, no raw frame, key, template, sensor imagery or sensitive logs. Verify a user action caused real sensor event from a legitimate secure provider, not an on-screen button.
3. Verify at least two independent real lock-screen matches and unlocks; wrong finger and no finger must be denied; perform cancellation; ten bounded success/fail cycles; deletion must revoke authorization. Test PIN fallback after every failure category.
4. Test malicious-client/unauthorized mutation denial (without leaking exploitable credentials), replay/stale-session denial, screen off/on, service restart, USB disconnect/reconnect, normal reboot, and suspend/resume if safe. Ensure TEE-authorized enrollment persists across reboot and deletion remains effective.
5. Capture owner-approved time-stamped evidence, exact daemon/kernel hashes, log excerpts with sensitive values redacted and a resource/thermal baseline. Test critical existing features: Wi-Fi, USB SSH, systemd, touch/display/rotation, NFC, sensors, camera and audio only with non-invasive relevant health checks; do not disturb them.
6. Each test is `PASS`, `FAIL`, `BLOCKED`, or `NOT_TESTED`, never inferred. A real fingerprint unlock must actually transition the Nuxel lock state under the secure owner broker. Do not accept hardware matches merely because JSON returned success.


## Mandatory exit artifact and next-phase gate

Deliver `reports/FINGERPRINT-09-REAL-HARDWARE-ACCEPTANCE.md` with a signed-off owner test receipt and evidence pointer for each security condition. Only if ALL essential real secure match/storage/lock/policy tests pass may `FINGERPRINT_WORKING=true` be written in final documentation.
