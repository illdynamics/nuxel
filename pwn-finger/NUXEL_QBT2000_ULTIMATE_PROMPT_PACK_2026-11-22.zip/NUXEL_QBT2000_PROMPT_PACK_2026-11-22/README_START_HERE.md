# Nuxel Galaxy S10+ QBT2000 — ultimate fingerprint continuation pack

**Snapshot audited:** uploaded `nuxel-ds-ssp (1)(2).zip`, Nov 22 2026, Nuxel version `v0.9.1-beta`. This pack does not claim access to the current running handset or missing `pwn/finger*.md` history.

## Verdict
The physical QBT2000 driver interface exists in historical live evidence, but a signed and functioning fingerprint secure-world provider and genuine enrollment/matching are not proven. The repository contains a custom fail-closed broker plus UI work, with substantial security and truthfulness problems to harden. **Estimated implementation progress ≈24% (subjective, ±10 percentage points); real working fingerprint unlock = 0% demonstrated.** The feature could remain externally blocked despite several AI agent rounds.

## Suggested model budget / order
1. **DeepSeek V4 Pro Thinking 1:** `01_LIVE_BASELINE...` — inventory live rootfs, code version, TEE, DT hashes, OEM provenance, missing `pwn/finger*.md`.
2. **DeepSeek V4 Pro Thinking 2:** `02_AUTH_BOUNDARY...` — fix authorization/attestation policy safely in source and validate host tests; no device flash.
3. **DeepSeek V4 Pro Thinking 3:** `03_OEM_TEE...` — confirm/reject exact signed TA+HAL path, locate first failing layer. This is the critical **GO/NO-GO**.
4. **DeepSeek V4 Pro Thinking 4, conditional:** `04_SECURE_ADAPTER...` — only when the matching, lawful vendor trust boundary is proven technically available.
5. **Fast/Flash model A:** `05_UI...` — remove deceptive enrollment path, wire truthful secure APIs, preserve PIN.
6. **Fast/Flash model B:** `06_TESTS...` — regression and negative-security test suite, no synthetic hardware PASS.
7. **Physical phone BOOT reflash (NOT a model round), exceptional only:** `07_CONDITIONAL_BOOT...`; if it fails use `08_TWRP_RECOVERY...` immediately.
8. **DeepSeek V4 Pro Thinking 5, conditional:** `09_PHYSICAL_ACCEPTANCE...` — owner-assisted real scans/lock tests.
9. **Fast/Flash model C:** `10_FINAL_REPORT...` — report/commit/docs/release gate.

You can combine stages 1–3 into two longer thinking rounds if the agent retains context, but do not skip their **evidence gates**. Stages 4 and 9 depend on vendor secure-world availability. TWRP is never an indication that a new Nuxel boot succeeded.

## Crucial architectural decision
Do not rewrite the already-detected QBT2000 kernel driver or alter DT just because fingerprint does not unlock. The read-only historical diagnostic shows `/dev/qbt2000_fd`, `/dev/qbt2000_ipc`, and sysfs `name=QBT2000`; a `tz:1` kernel field is NOT TEE fingerprint authentication. Investigate the actual secure OS -> matching signed trustlet -> normal-world vendor HAL/ABI -> Nuxel broker chain. Research on public code is useful, but missing signed OEM components cannot be recreated by a code model.

## Rules for a fast agent
A fast model may execute deterministic refactors, test implementation, interface cleanup, and documentation only after the thinking agent writes an architecture / acceptance / files-to-change manifest. It may not independently decide to modify DT, flash BOOT, attempt secure-world replacement, or declare a physical biometric pass.

## Source-of-truth notes
- This archive does not contain `.git`, `reports/` or `packs/`, and no `pwn/finger1.md`, `finger2.md` etc.; avoid claims about their latest contents.
- `services/nuxel-bridge/src/fingerprint_provider.py` exposes the new `nuxel.fingerprint-status/2` in source; earlier live dumps show schema `/1`, so verify the deployed revision rather than assuming snapshot parity.
- External starting references: LineageOS Exynos9820 common `common.mk` fingerprint service and `proprietary-files.txt` TEE list, AOSP biometric security design. They are leads, not working Nuxel artifacts.

Read `FINGERPRINT_AUDIT_AND_RISK_REGISTER.md` for evidence, issue severity and the exact missing items.
