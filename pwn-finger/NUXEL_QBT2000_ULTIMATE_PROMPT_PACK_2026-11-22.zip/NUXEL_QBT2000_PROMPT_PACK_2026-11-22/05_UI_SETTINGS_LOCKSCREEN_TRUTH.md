# NUXEL QBT2000 / 05: UI SETTINGS LOCKSCREEN TRUTH

**Recommended executor:** DeepSeek Flash / fast implementation model (no flash to device BOOT)

**Mission:** Make Settings and Home accurately reflect physical secure-provider state and preserve the PIN path, without any simulated enrollment success.

## Non-negotiable contract — read this before acting
- Device scope: only the owner-approved Samsung Galaxy S10+ SM-G975F `beyond2lte`, Exynos9820, Nuxel/Fedora 43, historical Samsung/Linux4 downstream 4.14.253. **Re-identify the physical device, boot, and source hashes before changing anything.** The ZIP is not proof of what is installed live.
- Preserve PIN/password/pattern unlock and the working phone. No fake enroll/match, no browser-simulated sensor evidence, no fabricated sensor, no templates/images/raw biometric data, no forged TEE attestation, no bypassing secure-boot, signed-TA checks, RPMB, TEE keys, or credential verification.
- **DT freeze by default:** no DTB, DTBO, dts, dtsi, reserved-memory, pinctrl, clocks, GPIO, power-rail or boot-header changes for this fingerprint mission. If hard evidence independently proves a DT change necessary, STOP and produce a separate evidence-based change request and rollback design for the owner; never quietly combine it with a fingerprint fix.
- Work in an isolated branch/worktree. Start with read-only commands; use host tests and reversible userspace changes before considering any device image. No blind `dd`, no generic `fastboot`, no guesses about partitions, no EFS/IMEI/NV/RPMB/calibration, no touch of modem, keys or user data. Never paste secrets into reports.
- Label every conclusion `PROVED_LIVE`, `HISTORICAL_LIVE`, `PRESENT_IN_ZIP`, `PROVED_IN_PINNED_SOURCE`, `UPSTREAM_CONCEPT_ONLY`, `INFERRED`, or `UNKNOWN`. Tie real tests to timestamp, boot/kernel hash, device identity, and captured redacted evidence. Unit mocks are not a hardware PASS.
- A flash is **conditional**, not an expected step. The established QBT2000 device nodes suggest the kernel already binds it. Never rewrite/flash the kernel just to feel progress. Use the historical `evidence/bootloop-0023-20261114-1002/FIX-REPORT.md` and `tools/s10plus/verify-boot-image.py` gates if a real flash becomes necessary.
- TWRP agreement: if a candidate reboots back to TWRP, it FAILED. Collect logs, compare candidate vs known-good, determine first failing stage, then restore verified known-good BOOT to boot Nuxel before any further experiment. Do not repeat the same failed image. A revised image may be retried only after correcting the demonstrated cause and passing all offline checks. Never spin indefinitely; if safe restoration is impossible, STOP and report precise recovery blockage.
- Avoid external artifact provenance mistakes: an example LineageOS `beyond1lte` TEE file is not proven compatible with this `beyond2lte` unit; inventory official owner-extracted matching builds, license and dependency hashes without distributing protected binaries.
- Treat technical blockers as explicit branch conditions. If the lawful signed TA/secure runtime cannot be demonstrated, finish all safe hardening, truthful status reporting, and a precise blocker manifest. Never claim genuine fingerprint functionality before owner-performed physical enrollment/verification and secure authentication tests pass.
- Primary historical inputs to inspect: `hw/NUXEL_02_QBT2000_FINGERPRINT_STANDALONE.md`, `diagnostics/pwnage-91000/hardware/fingerprint-live.txt`, `services/nuxel-bridge/src/{fingerprint_provider.py,security_provider.py,api.py}`, `pwa/nuxel-apps/settings/{index.html,pwange45000-settings.js}`, `pwa/nuxel-home/js/lockscreen-auth.js`, `tools/a80/fingerprint-enroll.py`, `configs/nuxel/security/biometric-unlock.json`, `device/s10plus/deviceinfo`, `evidence/bootloop-0023-20261114-1002/FIX-REPORT.md`. The uploaded ZIP DOES NOT contain `pwn/finger*.md`, `reports/REPORT-FINGERPRINT.md` or `packs/finger/`; look for these in the *actual* live repository and flag them missing if unavailable.

## Execute, in this order

1. Read the accepted stage 02 patch and either stage 03 blocker or stage 04 broker contract. Work only in `pwa/nuxel-apps/settings`, `pwa/nuxel-home` and allowed public bridge read APIs; do not change kernel/DT or secure authentication logic.
2. In Settings remove/hide the existing `ceremony-touch` edge-button simulation (`aria-label=Simulate scanner touch`) as a production enrollment option. If no TEE/TA, show disabled enrollment and a comprehensible blocker; 'enrolled' must only mean secure-provider enrolled, never HMAC metadata.
3. If a real provider exists, wire enrollment to actual server-originated sensor progress, explicit owner credential check, cancellation and secure slot enumeration. Separate physical progress from on-screen animation; no browser-issued 'finger touched' calls.
4. Preserve lockscreen PIN fallback in every failed/locked/offline/suspend/reboot state. Never auto-select fingerprint or clear the PIN. Provider error must not strand the user on a dead scanner overlay.
5. Show real 'secure provider ready', 'not enrolled', 'temporarily unavailable', 'blocked TEE', or 'locked out' states; prevent misleading `supported`/`enrollment_supported` combinations. On delete confirm actual secure slot disappearance before displaying success.
6. Update accessibility, focus, button disabled states, translations if applicable and dedicated UI regression tests. No biometric data in browser storage or logs.


## Mandatory exit artifact and next-phase gate

Deliver source diff + `reports/FINGERPRINT-05-UI.md`, deterministic node/JS tests and screenshots only if observed on actual UI. State explicitly whether hardware enrollment was performed or not. No boot flash.
