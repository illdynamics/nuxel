# NUXEL QBT2000 / 08: TWRP RECOVERY IF NEW BOOT FAILS

**Recommended executor:** TWRP emergency follow-up (use only after failed candidate)

**Mission:** Recover a usable Nuxel boot after a fingerprint-related boot deployment returns to TWRP, using a verified known-good image—not blind retry.

## Non-negotiable contract — read this before acting
- Device scope: only the owner-approved Samsung Galaxy S10+ SM-G975F `beyond2lte`, Exynos9820, Nuxel/Fedora 43, historical Samsung/Linux4 downstream 4.14.253. **Re-identify the physical device, boot, and source hashes before changing anything.** The ZIP is not proof of what is installed live.
- Preserve PIN/password/pattern unlock and the working phone. No fake enroll/match, no browser-simulated sensor evidence, no fabricated sensor, no templates/images/raw biometric data, no forged TEE attestation, no bypassing secure-boot, signed-TA checks, RPMB, TEE keys, or credential verification.
- **DT freeze by default:** no DTB, DTBO, dts, dtsi, reserved-memory, pinctrl, clocks, GPIO, power-rail or boot-header changes for this fingerprint mission. If hard evidence independently proves a DT change necessary, STOP and produce a separate evidence-based change request and rollback design for the owner; never quietly combine it with a fingerprint fix.
- Work in an isolated branch/worktree. Start with read-only commands; use host tests and reversible userspace changes before considering any device image. No blind `dd`, no generic `fastboot`, no guesses about partitions, no EFS/IMEI/NV/RPMB/calibration, no touch of modem, keys or user data. Never paste secrets into reports.
- Label every conclusion `PROVED_LIVE`, `HISTORICAL_LIVE`, `PRESENT_IN_ZIP`, `PROVED_IN_PINNED_SOURCE`, `UPSTREAM_CONCEPT_ONLY`, `INFERRED`, or `UNKNOWN`. Tie real tests to timestamp, boot/kernel hash, device identity, and captured redacted evidence. Unit mocks are not a hardware PASS.
- A flash is **conditional**, not an expected step. The established QBT2000 device nodes suggest the kernel already binds it. Never rewrite/flash the kernel just to feel progress. Use the historical `evidence/bootloop-0023-20261114-1002/FIX-REPORT.md` and `tools/s10plus/verify-boot-image.py` gates if a real flash becomes necessary.
- TWRP agreement: if a candidate reboots back to TWRP, it FAILED. Collect logs, compare candidate vs known-good, determine first failing stage, then restore verified known-good BOOT to boot Nuxel before any further experiment. Do not repeat the same failed image. A revised image may be retried only after correcting the demonstrated cause and passing all offline checks. Never spin indefinitely; if safe restoration is impossible, STOP and report precise recovery blockage.
- Avoid external artifact provenance mistakes: an example LineageOS `beyond1lte` TEE file is not proven compatible with this `beyond2lte` unit; inventory official owner-extracted matching builds, license and dependency hashes without distributing protected binaries.
- Treat technical blockers as explicit branch conditions. If the lawful signed TA/secure runtime cannot be demonstrated, finish all safe hardening, truthful status reporting, and a precise blocker manifest. Never claim genuine fingerprint functionality before owner-performed physical enrollment/verification and secure authentication tests pass.
- Primary historical inputs to inspect: `hw/NUXEL_02_QBT2000_FINGERPRINT_STANDALONE.md`, `diagnostics/pwnage-91000/hardware/fingerprint-live.txt`, `services/nuxel-bridge/src/{fingerprint_provider.py,security_provider.py,api.py}`, `pwa/nuxel-apps/settings/{index.html,pwange45000-settings.js}`, `pwa/nuxel-home/js/lockscreen-auth.js`, `tools/a80/fingerprint-enroll.py`, `configs/nuxel/security/biometric-unlock.json`, `device/s10plus/deviceinfo`, `evidence/bootloop-0023-20261114-1002/FIX-REPORT.md`. The uploaded ZIP DOES NOT contain `pwn/finger*.md`, `reports/REPORT-FINGERPRINT.md` or `packs/finger/`; look for these in the *actual* live repository and flag them missing if unavailable.

## Execute, in this order

1. A reboot back into TWRP is unequivocally **FAILURE**, not a warning and not the new kernel booting. Stop any automation that intends to mark the candidate successful. Confirm exact device/recovery via host evidence and preserve logs/pstore/console if present without writing unrelated partitions.
2. Determine earliest failure stage: Samsung bootloader/header/raw Image/partition truncation; DTB/DTBO address/mismatch; initramfs/root mount; kernel panic; service crash; Nuxel userspace. Compare candidate with known-good using hash and structural inspection, not guesses.
3. Restore the exact previously hash-verified known-good BOOT using the already proven TWRP path and only the verified device BOOT target. Read-back verify the written bytes and reboot. Require actual Nuxel UI + systemd + PIN + SSH health receipt before any new experimental build.
4. If known-good fails too, DO NOT touch DTBO, secure stores, EFS, modem or bootloader. Preserve TWRP, capture current partition/PIT and error logs, and report an explicit recovery blocker for owner involvement. Never issue destructive formatting to make it boot.
5. If known-good succeeds, do offline root-cause analysis and rebuild a genuinely different, corrected candidate only where a precise safe fix exists. Re-run every immutable-DT, image header, capacity, ramdisk and TWRP rollback gate. Otherwise stop and retain the healthy known-good boot.


## Mandatory exit artifact and next-phase gate

Deliver `reports/FINGERPRINT-08-TWRP-RECOVERY.md`: failed candidate hash, observed first failure, logs, known-good restored hash, successful Nuxel/PIN/SSH checks, and whether future device flashing is prohibited. Avoid indefinite reflash loops.
