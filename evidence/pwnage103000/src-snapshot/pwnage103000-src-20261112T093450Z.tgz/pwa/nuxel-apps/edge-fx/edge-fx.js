/* Nuxel Edge FX (PWNAGE-103000)
 *
 * The installable app surface for Edge Lighting + the Edge Panel:
 *   - enable/disable, pick and preview any of the eight effects;
 *   - colour mode, width, transparency, duration, DND / reduced-motion policy,
 *     screen-state capability (screen-off is reported unavailable, not faked);
 *   - notification source allowlist from the CANONICAL registry;
 *   - open the Edge panel from either side;
 *   - uninstall / reinstall this app through the canonical app registry RPC
 *     (`apps` namespace, owner-gated to Home / Settings / NuxTore on the host).
 *
 * All state lives in the one Edge Lighting document owned by the bridge
 * provider; this page never writes a file and never touches an LED.
 */
(function () {
  'use strict';
  var FALLBACK_EFFECTS = ['basic', 'wave', 'bubble', 'multicolor', 'heart', 'fireworks', 'eclipse', 'echo'];
  var LABELS = { basic: 'Basic', wave: 'Wave', bubble: 'Bubble', multicolor: 'Multicolor',
                 heart: 'Heart', fireworks: 'Fireworks', eclipse: 'Eclipse', echo: 'Echo' };
  var PRESETS = ['#63f0bd', '#4aa8ff', '#ffb454', '#ff6b6b', '#c77dff', '#ffffff', '#ff8fab'];
  var APP_ID = 'nuxel-edge-fx';
  var START_URL = '/pwa/nuxel-apps/edge-fx/index.html';
  var $ = function (id) { return document.getElementById(id); };
  var settings = null, capability = null, effects = FALLBACK_EFFECTS, registryApps = [];

  var API_BASE = window.NUXEL_API_URL || 'http://127.0.0.1:8080/api/v1';
  /* Prefer the shared bridge client (version pin + session token).  A plain
     bootstrap-token fetch is the fallback on the local loopback API so the
     effect picker still works if the ES module failed to load; a version-skew
     refusal from the shared client is never masked. */
  function bridge() { return window.NuxelBridge; }

  function call(ns, verb, params) {
    var b = bridge();
    if (b && b.call) return Promise.resolve(b.call(ns, verb, params || {}));
    return fetchApi(ns, verb, params);
  }

  var token = null;
  function apiFetch(path, opts) {
    opts = opts || {};
    opts.headers = opts.headers || { 'Content-Type': 'application/json', 'X-Nuxel-Bridge-Version': '1' };
    if (token) opts.headers.Authorization = 'Bearer ' + token;
    opts.cache = 'no-store';
    return fetch(API_BASE + path, opts).then(function (r) {
      return r.json().then(function (body) {
        if (!r.ok) {
          var e = new Error('HTTP ' + r.status + (body && body.error ? ' (' + body.error + ')' : ''));
          e.body = body;
          throw e;
        }
        return body;
      });
    });
  }
  function fetchApi(ns, verb, params) {
    if (token) return rpc();
    return apiFetch('/auth/token', {
      method: 'POST', body: JSON.stringify({ app_id: 'nuxel-edge-fx' })
    }).then(function (res) { token = (res && res.token) || ''; return rpc(); });
    function rpc() {
      return apiFetch('/rpc', {
        method: 'POST',
        body: JSON.stringify({ app_id: 'nuxel-edge-fx', namespace: ns, verb: verb, params: params || {} })
      }).then(function (res) { return (res && res.result !== undefined) ? res.result : res; });
    }
  }

  function say(msg) { var el = $('state'); if (el) el.textContent = msg; }

  /* The Home engine is the single source of effect names/labels.  Reach it
     through the framing Home document (same origin on the phone) and fall back
     to the local list only when there is no Home frame (desktop preview). */
  function homeEngine() {
    try {
      var p = window.parent;
      if (p && p !== window && p.NuxelEdgeLighting && p.NuxelEdgeLighting.effects) return p.NuxelEdgeLighting;
    } catch (e) { /* cross-origin */ }
    return null;
  }
  (function adoptEngine() {
    var engine = homeEngine();
    if (!engine) return;
    effects = engine.effects.slice();
    engine.effects.forEach(function (e) { LABELS[e] = engine.labels[e] || LABELS[e] || e; });
  })();

  function renderEffects() {
    var host = $('effects');
    host.textContent = '';
    effects.forEach(function (eff) {
      var tile = document.createElement('button');
      tile.type = 'button';
      tile.className = 'effect-tile';
      tile.setAttribute('role', 'radio');
      tile.setAttribute('data-effect', eff);
      tile.setAttribute('aria-checked', settings && settings.effect === eff ? 'true' : 'false');
      var sample = '<span class="fx-sample fx-' + eff + '">';
      var count = eff === 'wave' || eff === 'bubble' || eff === 'heart' || eff === 'fireworks' || eff === 'echo' ? 3 : 1;
      for (var i = 0; i < count; i++) sample += '<i></i>';
      sample += '</span>';
      tile.innerHTML = sample + '<span class="fx-name">' + LABELS[eff] + (eff === 'wave' ? ' (default)' : '') + '</span>';
      tile.addEventListener('click', function () {
        // Preview first on the real display, then persist the selection.
        var engine = homeEngine();
        if (engine && engine.preview) engine.preview(eff);
        save({ effect: eff }).then(function () { say('Effect: ' + LABELS[eff] + ' (previewed and saved)'); });
      });
      host.appendChild(tile);
    });
  }

  function renderSwatches() {
    var host = $('swatches');
    host.textContent = '';
    PRESETS.forEach(function (c) {
      var b = document.createElement('button');
      b.type = 'button';
      b.style.background = c;
      b.setAttribute('aria-label', 'Colour ' + c);
      b.setAttribute('aria-pressed', settings && String(settings.color).toLowerCase() === c ? 'true' : 'false');
      b.addEventListener('click', function () { save({ color_mode: 'preset', color: c }); });
      host.appendChild(b);
    });
  }

  function renderSources() {
    var host = $('sources');
    host.textContent = '';
    var allowed = (settings && settings.allowed_apps) || [];
    registryApps.slice(0, 80).forEach(function (app) {
      var label = document.createElement('label');
      var cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.checked = allowed.indexOf(app.id) >= 0;
      cb.addEventListener('change', function () {
        var next = allowed.slice();
        var i = next.indexOf(app.id);
        if (cb.checked && i < 0) next.push(app.id);
        if (!cb.checked && i >= 0) next.splice(i, 1);
        save({ allowed_apps: next }).then(function (ok) {
          if (!ok) cb.checked = !cb.checked;
          say(ok ? (next.length ? next.length + ' app(s) allowed' : 'All apps may light the edge') : 'Could not save sources');
        });
      });
      label.appendChild(cb);
      label.appendChild(document.createTextNode(app.name || app.id));
      host.appendChild(label);
    });
    if (!registryApps.length) host.textContent = 'App registry unavailable — source filtering stays unchanged.';
  }

  function fill(s) {
    settings = s;
    if ($('enabled')) $('enabled').checked = !!s.enabled;
    if ($('color-mode')) $('color-mode').value = s.color_mode || 'theme';
    if ($('width')) $('width').value = s.width || 'medium';
    if ($('transparency')) $('transparency').value = s.transparency || 'medium';
    if ($('duration')) $('duration').value = s.duration_ms;
    if ($('duration-out')) $('duration-out').textContent = (s.duration_ms / 1000).toFixed(1) + ' s';
    if ($('dnd')) $('dnd').checked = s.respect_dnd !== false;
    if ($('rm')) $('rm').checked = s.respect_reduced_motion !== false;
    if ($('screen-mode')) $('screen-mode').value = 'screen_on';
    if ($('custom-color') && s.color) $('custom-color').value = s.color;
    $('swatches').hidden = s.color_mode !== 'preset';
    $('custom-row').hidden = s.color_mode !== 'custom';
    renderEffects();
    renderSwatches();
    renderSources();
  }

  function save(patch) {
    var b = bridge();
    if (!b || !b.call) { say('Bridge unavailable: settings were not saved.'); return Promise.resolve(false); }
    return call('edge-lighting', 'set', patch).then(function (res) {
      if (res && res.success && res.config) {
        fill(res.config);
        if (window.NuxelEdgeLighting && window.NuxelEdgeLighting.reload) window.NuxelEdgeLighting.reload();
        return true;
      }
      say('Not saved: ' + ((res && (res.error || res.detail)) || 'provider refused the change'));
      return false;
    }, function (err) {
      say('Not saved: ' + (err && err.message ? err.message : 'bridge error'));
      return false;
    });
  }

  function loadStatus() {
    return call('edge-lighting', 'status', {}).then(function (res) {
      if (!res || !res.success) {
        say('Edge lighting provider unavailable: ' + ((res && res.error) || 'no response'));
        return;
      }
      capability = res.capability || null;
      if (capability && capability.effects_supported) effects = capability.effects_supported;
      fill(res.config || {});
      var lines = [];
      lines.push('Effect: ' + LABELS[settings.effect] + ' · ' + (settings.enabled ? 'enabled' : 'off') +
        ' · ' + settings.duration_ms + ' ms');
      lines.push('DND: ' + (res.dnd && res.dnd.active ? 'active (' + res.dnd.reason + ')' : 'off') +
        ' · provider: ' + (res.last_error ? 'last error: ' + res.last_error : 'ok'));
      say(lines.join('\n'));
      if (capability && $('capability')) {
        var modes = (capability.screen_modes || []).map(function (m) {
          return m.id + ': ' + (m.available ? 'available' : 'unavailable');
        }).join(' · ');
        $('capability').textContent = 'AMOLED display effect, not a hardware LED. Screen modes — ' + modes;
        var off = (capability.screen_modes || []).filter(function (m) { return m.id === 'screen_off'; })[0];
        if ($('screen-note')) $('screen-note').textContent = off && off.reason ? off.reason : '';
      }
    }, function (err) {
      say('Edge lighting provider unavailable: ' + (err && err.message ? err.message : 'bridge error'));
    });
  }

  function loadRegistry() {
    return call('apps', 'inventory', {}).then(function (res) {
      var list = (res && res.apps) || [];
      registryApps = list.map(function (a) { return { id: a.id, name: a.name || a.id, state: a.state }; });
      var me = list.filter(function (a) { return a.id === APP_ID; })[0];
      var installed = !!(me && me.registered !== false);
      $('install-state').textContent = installed
        ? 'Installed (state: ' + (me.state || 'registered') + '). Uninstall removes only the launcher entry.'
        : 'Not installed in the canonical registry. Install re-registers this app from its local bundle.';
      $('uninstall').disabled = !installed;
      $('reinstall').disabled = false;
      renderSources();
    }, function (err) {
      $('install-state').textContent = 'Registry unavailable: ' + (err && err.message ? err.message : 'bridge error');
    });
  }

  function bind() {
    $('close').addEventListener('click', function () {
      try { if (window.parent && window.parent !== window && window.parent.nuxel && window.parent.nuxel.home) window.parent.nuxel.home(); } catch (e) {}
      try { history.back(); } catch (e) {}
    });
    $('enabled').addEventListener('change', function () {
      save({ enabled: $('enabled').checked }).then(function (ok) { if (ok) say('Edge lighting ' + ($('enabled').checked ? 'on' : 'off')); });
    });
    $('color-mode').addEventListener('change', function () {
      var mode = $('color-mode').value;
      $('swatches').hidden = mode !== 'preset';
      $('custom-row').hidden = mode !== 'custom';
      save({ color_mode: mode, color: mode === 'theme' ? null : (settings.color || $('custom-color').value) });
    });
    $('custom-color').addEventListener('change', function () {
      save({ color_mode: 'custom', color: $('custom-color').value });
    });
    $('width').addEventListener('change', function () { save({ width: $('width').value }); });
    $('transparency').addEventListener('change', function () { save({ transparency: $('transparency').value }); });
    $('duration').addEventListener('input', function () {
      $('duration-out').textContent = (parseInt($('duration').value, 10) / 1000).toFixed(1) + ' s';
    });
    $('duration').addEventListener('change', function () { save({ duration_ms: parseInt($('duration').value, 10) }); });
    $('dnd').addEventListener('change', function () { save({ respect_dnd: $('dnd').checked }); });
    $('rm').addEventListener('change', function () { save({ respect_reduced_motion: $('rm').checked }); });
    $('sources-clear').addEventListener('click', function () { save({ allowed_apps: [] }); });
    $('preview').addEventListener('click', function () {
      var engine = homeEngine();
      if (engine && engine.preview) {
        engine.preview(settings.effect);
        say('Previewing ' + LABELS[settings.effect] + ' — no notification was created or changed.');
      } else say('Preview unavailable in this view.');
    });
    $('reset').addEventListener('click', function () {
      call('edge-lighting', 'reset', {}).then(function (res) {
        if (res && res.success && res.config) { fill(res.config); say('Reset to defaults: Wave, theme accent, 1800 ms.'); }
        else say('Reset failed: ' + ((res && res.error) || 'provider refused'));
      });
    });
    $('panel-left').addEventListener('click', function () { openPanel('left'); });
    $('panel-right').addEventListener('click', function () { openPanel('right'); });
    $('uninstall').addEventListener('click', function () {
      if (!window.confirm('Uninstall Edge FX from the launcher? Settings and the Edge engine stay.')) return;
      call('apps', 'unregister', { app_id: APP_ID }).then(function (res) {
        if (res && res.success) { $('install-state').textContent = 'Uninstalled. Use Install / reinstall to add it back.'; loadRegistry(); }
        else $('install-state').textContent = 'Uninstall refused: ' + ((res && (res.error || res.detail)) || 'unknown');
      });
    });
    $('reinstall').addEventListener('click', function () {
      call('apps', 'register', {
        app_id: APP_ID, name: 'Edge FX', start_url: START_URL, version: '0.8.3-beta'
      }).then(function (res) {
        if (res && res.success) { $('install-state').textContent = 'Installed (state: ' + (res.state || 'installed') + ').'; loadRegistry(); }
        else $('install-state').textContent = 'Install refused: ' + ((res && (res.error || res.detail)) || 'unknown');
      });
    });
  }

  function openPanel(side) {
    // This page is usually framed inside Home; the panel belongs to the Home
    // document so it can overlay the app frame and reuse the Home registry.
    var targets = [window.parent, window];
    for (var i = 0; i < targets.length; i++) {
      try {
        var api = targets[i].NuxelEdgeLighting;
        if (api && api.openPanel) { api.openPanel(side, 'edge-fx-app'); return; }
      } catch (e) { /* cross-origin frame: try the next target */ }
    }
    say('The Edge panel is available from Home (side swipe or the Quick Settings Edge tile).');
  }

  function init() {
    bind();
    loadStatus();
    loadRegistry();
    document.addEventListener('nuxel:edge-lighting-changed', function (ev) {
      if (ev && ev.detail && ev.detail.config) fill(ev.detail.config);
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();
