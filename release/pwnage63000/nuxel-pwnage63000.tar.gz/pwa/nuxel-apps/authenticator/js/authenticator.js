// Nuxel Authenticator — UI over the encrypted vault.  No network code exists in
// this app: the only storage is the AES-GCM envelope in localStorage, and the
// only crypto is WebCrypto.
(function () {
  'use strict';
  var V = window.AuthVault, T = window.NuxelTotp;
  var KEY = 'nuxel-authenticator-envelope-v1';
  var el = function (id) { return document.getElementById(id); };
  var state = {
    env: null, key: null, accounts: [], filter: '', tick: null, codes: {},
    keyring: { status: 'unknown', locked: null, linked: null, notInitialized: false,
               autoBusy: false, poll: null },
    clip: null
  };

  function toast(m) {
    var t = el('toast'); t.textContent = m; t.classList.add('show');
    clearTimeout(toast._t); toast._t = setTimeout(function () { t.classList.remove('show'); }, 2800);
  }
  function esc(s) { return String(s === null || s === undefined ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function loadEnv() { try { var raw = localStorage.getItem(KEY); return raw ? JSON.parse(raw) : null; } catch (e) { return null; } }
  function storeEnv(env) {
    try { localStorage.setItem(KEY, JSON.stringify(env)); return true; }
    catch (e) { toast('could not save the vault: ' + e.message); return false; }
  }

  /* ---------------- Nuxel Keyring (fail closed) ---------------- */

  function kr(verb, params) {
    if (!window.NuxelBridge || typeof window.NuxelBridge.keyring !== 'function') {
      return Promise.resolve({ success: false, state: 'unavailable', offline: true,
        error: 'bridge_unreachable', detail: 'Nuxel Bridge keyring client unavailable' });
    }
    return window.NuxelBridge.keyring(verb, params || {});
  }

  function krError(res) {
    var code = res && res.error;
    if (code === 'collection_locked') return 'The Nuxel Keyring is locked.';
    if (code === 'provider_unavailable') return 'The Nuxel Keyring provider is unavailable.';
    if (code === 'invalid_credentials') return 'The keyring master password did not unlock it.';
    if (code === 'rate_limited') return 'Too many failed keyring unlock attempts. Wait a moment.';
    if (code === 'item_not_found') return 'No saved Authenticator credential exists.';
    if (code === 'permission_denied') return 'The bridge denied the keyring operation.';
    if (code === 'timeout') return 'The keyring provider did not answer in time.';
    return (res && (res.detail || res.error)) || 'The keyring operation failed.';
  }

  function keyringLabel() {
    var k = state.keyring;
    if (k.status === 'unavailable') return 'Provider unavailable — manual passphrase only.';
    if (!state.env) return 'Create the Authenticator vault first; linking is available in Security.';
    if (k.notInitialized) return 'Nuxel Keyring is not initialized. Open Nuxel Vault to create it.';
    if (k.locked) {
      return k.linked === true ? 'Linked — keyring locked.' :
        'Keyring locked. Unlock it to check whether a saved credential exists.';
    }
    if (k.linked === true) return 'Linked — keyring unlocked.';
    if (k.linked === false) return 'Not linked — manual passphrase only.';
    return 'Keyring unlocked; credential status unknown.';
  }

  function updateKeyringUi() {
    var k = state.keyring;
    var status = keyringLabel();
    if (el('kr-lock-status')) el('kr-lock-status').textContent = status;
    if (el('kr-status')) el('kr-status').textContent = status;
    var showCard = !!state.env;
    if (el('kr-lock-card')) el('kr-lock-card').hidden = !showCard;
    var canUnlock = showCard && !k.notInitialized && k.status !== 'unavailable' && k.locked === true;
    if (el('kr-unlock-row')) el('kr-unlock-row').hidden = !canUnlock;
    if (el('kr-auto-row')) el('kr-auto-row').hidden = !(showCard && !k.locked && k.linked === true && !state.key);
    if (el('kr-unlink')) el('kr-unlink').disabled = !(k.linked === true);
  }

  async function refreshKeyringState(autoUnlock) {
    var st = await kr('status');
    if (!st.success) {
      state.keyring.status = 'unavailable';
      state.keyring.locked = null;
      state.keyring.linked = null;
      state.keyring.notInitialized = false;
      updateKeyringUi();
      return state.keyring;
    }
    state.keyring.status = st.state || (st.locked ? 'collection_locked' : 'unlocked');
    state.keyring.notInitialized = st.state === 'not_initialized';
    state.keyring.locked = !!st.locked || st.state === 'collection_locked';
    var cs = await kr('authenticator-credential-status');
    if (cs.success) {
      if (cs.exists === true) state.keyring.linked = true;
      else if (cs.exists === false) state.keyring.linked = false;
      else if (cs.state === 'keyring_locked') state.keyring.linked = null;
    }
    updateKeyringUi();
    if (autoUnlock && state.env && !state.key && state.keyring.linked === true && !state.keyring.locked) {
      await autoUnlockFromKeyring();
    }
    return state.keyring;
  }

  async function autoUnlockFromKeyring() {
    if (!state.env || state.key || state.keyring.autoBusy) return false;
    if (state.keyring.linked !== true || state.keyring.locked || state.keyring.status === 'unavailable') {
      updateKeyringUi();
      return false;
    }
    state.keyring.autoBusy = true;
    var pass = null;
    try {
      var res = await kr('authenticator-credential-get');
      if (!res.success || !res.credential) {
        el('lock-error').textContent = 'The saved Nuxel Keyring credential could not be read. Enter the passphrase manually or re-link.';
        return false;
      }
      pass = String(res.credential);
      res.credential = null;
      try {
        var un = await V.unlock(state.env, pass);
        state.key = un.key;
        state.accounts = un.accounts;
        showMain();
        toast('Unlocked with Nuxel Keyring');
        return true;
      } catch (e) {
        el('lock-error').textContent = 'The saved Nuxel Keyring credential did not open this vault. Enter the passphrase manually or re-link.';
        return false;
      }
    } finally {
      pass = null;
      state.keyring.autoBusy = false;
    }
  }

  async function keyringUnlockAction() {
    var pass = el('kr-unlock-pass').value;
    el('kr-unlock-error').textContent = '';
    if (!pass) { el('kr-unlock-error').textContent = 'Enter the Nuxel Keyring master password.'; return; }
    var res = await kr('unlock', { master_password: pass });
    pass = null;
    el('kr-unlock-pass').value = '';
    if (!res.success) { el('kr-unlock-error').textContent = krError(res); return; }
    await refreshKeyringState(false);
    if (state.keyring.linked === true) await autoUnlockFromKeyring();
  }

  async function linkKeyringCredential() {
    var note = el('kr-link-note');
    note.textContent = '';
    var pass = el('kr-link-pass').value;
    if (!state.env || !state.key) { note.textContent = 'Unlock the Authenticator vault manually first.'; return; }
    if (!el('kr-consent').checked) { note.textContent = 'Explicit consent is required before storing the passphrase.'; return; }
    if (!pass) { note.textContent = 'Enter the current Authenticator passphrase to verify it.'; return; }
    try {
      await V.unlock(state.env, pass);
    } catch (e) {
      pass = null;
      el('kr-link-pass').value = '';
      note.textContent = 'That is not the current passphrase for this vault.';
      return;
    }
    var res = await kr('authenticator-credential-store', { credential: pass, consent: true });
    pass = null;
    el('kr-link-pass').value = '';
    if (!res.success) { note.textContent = krError(res); return; }
    state.keyring.linked = true;
    await refreshKeyringState(false);
    note.textContent = 'Saved in the Nuxel Keyring. Authenticator will auto-unlock only while the keyring is unlocked.';
    toast('Linked to Nuxel Keyring');
  }

  async function unlinkKeyringCredential() {
    if (!state.keyring.linked) { el('kr-link-note').textContent = 'No saved credential is linked.'; return; }
    if (!window.confirm('Remove the saved Authenticator passphrase from the Nuxel Keyring? Your TOTP accounts stay in the encrypted vault.')) return;
    var res = await kr('authenticator-credential-delete');
    if (!res.success) { el('kr-link-note').textContent = krError(res); return; }
    state.keyring.linked = false;
    await refreshKeyringState(false);
    el('kr-link-note').textContent = 'Saved credential removed. The encrypted TOTP vault is unchanged and manual unlock still works.';
    toast('Saved credential removed');
  }

  function startKeyringPoll() {
    if (state.keyring.poll) clearInterval(state.keyring.poll);
    state.keyring.poll = setInterval(async function () {
      if (!state.key || state.keyring.linked === false) return;
      var st = await kr('status');
      if (!st.success || st.state !== 'unlocked' || st.locked) {
        lockVault('keyring');
      }
    }, 30000);
  }

  function stopKeyringPoll() {
    if (state.keyring.poll) { clearInterval(state.keyring.poll); state.keyring.poll = null; }
  }

  /* ---------------- clipboard (OTP) ---------------- */

  function trackOtpClipboard(value) {
    state.clip = { value: String(value) };
    if (state.clip.timer) clearTimeout(state.clip.timer);
    state.clip.timer = setTimeout(clearOtpClipboardIfSame, 30000);
  }

  async function clearOtpClipboardIfSame() {
    var tracked = state.clip;
    state.clip = null;
    if (!tracked) return;
    if (tracked.timer) clearTimeout(tracked.timer);
    try {
      var now = await navigator.clipboard.readText();
      if (now === tracked.value) await navigator.clipboard.writeText('');
    } catch (e) { /* never erase a value we cannot verify */ }
  }

  /* ---------------- lock screen ---------------- */

  function renderLock() {
    var exists = !!state.env;
    el('lock-title').textContent = exists ? 'Unlock vault' : 'Create vault';
    el('lock-hint').textContent = exists
      ? 'Enter the passphrase. It is never stored anywhere — losing it means the secrets are unrecoverable, by design.'
      : 'Choose a passphrase for this device. There is no recovery, no reset e-mail and no cloud copy.';
    el('confirm-row').style.display = exists ? 'none' : 'flex';
    el('lock-go').textContent = exists ? 'Unlock' : 'Create vault';
    el('lock-error').textContent = '';
    el('pass').value = ''; el('pass2').value = '';
    el('screen-lock').style.display = 'block';
    el('screen-main').style.display = 'none';
    el('header-state').textContent = exists ? 'locked' : 'no vault';
    el('header-state').className = 'badge ' + (exists ? 'warn' : 'bad');
    if (el('kr-unlock-error')) el('kr-unlock-error').textContent = '';
    updateKeyringUi();
  }

  function showMain() {
    el('screen-lock').style.display = 'none';
    el('screen-main').style.display = 'block';
    el('header-state').textContent = 'unlocked';
    el('header-state').className = 'badge ok';
    renderAccounts();
    startTicker();
    el('vault-kdf').textContent = state.env.kdf.name + '-' + state.env.kdf.hash + ' · ' + state.env.kdf.iterations + ' iterations';
    el('vault-count').textContent = state.accounts.length + ' account(s)';
    startKeyringPoll();
    refreshKeyringState(false);
  }

  function lockVault(reason) {
    state.key = null;
    state.accounts = [];
    state.codes = {};
    stopQr(false);
    stopKeyringPoll();
    clearOtpClipboardIfSame();
    if (state.tick) { clearInterval(state.tick); state.tick = null; }
    state.filter = '';
    if (el('search')) el('search').value = '';
    if (el('codes')) el('codes').textContent = '';
    if (el('header-code-count')) el('header-code-count').textContent = '';
    renderLock();
    if (reason) toast('Vault locked');
  }

  async function lockAction() {
    var pass = el('pass').value, pass2 = el('pass2').value;
    el('lock-error').textContent = '';
    try {
      if (!state.env) {
        if (pass !== pass2) throw new Error('the two passphrases do not match');
        var v = await V.create(pass);
        state.env = v.envelope; state.key = v.key; state.accounts = [];
        if (!storeEnv(state.env)) {
          state.key = null; state.accounts = [];
          throw new Error('the encrypted vault could not be stored on this device');
        }
        showMain(); toast('Vault created');
        refreshKeyringState(false);
        return;
      }
      var un = await V.unlock(state.env, pass);
      state.key = un.key; state.accounts = un.accounts;
      showMain(); toast('Unlocked');
      refreshKeyringState(false);
    } catch (e) {
      el('lock-error').textContent = e.message;
    }
  }

  /* ---------------- codes ---------------- */

  function visible() {
    var q = state.filter.toLowerCase();
    return state.accounts.filter(function (a) {
      return !q || (a.issuer + ' ' + a.account).toLowerCase().indexOf(q) !== -1;
    });
  }

  function group(code) {
    // 6 digits -> 3+3, 8 digits -> 4+4; anything else is left untouched.
    if (/^\d{6}$/.test(code)) return code.slice(0, 3) + ' ' + code.slice(3);
    if (/^\d{8}$/.test(code)) return code.slice(0, 4) + ' ' + code.slice(4);
    return code;
  }

  async function renderCodes() {
    var now = Math.floor(Date.now() / 1000);
    var host = el('codes');
    var list = visible();
    if (!list.length) {
      host.innerHTML = '<p class="hint">' + (state.accounts.length ? 'No account matches that filter.' :
        'The vault is empty. Add an account with “Add account”, or paste an otpauth:// URI.') + '</p>';
      return;
    }
    for (let i = 0; i < list.length; i++) {
      const a = list[i];
      var counter = Math.floor(now / a.period);
      // The code only changes when the counter changes, so the HMAC is computed
      // once per period per account (the ticker runs 2x/s for the countdown).
      var cacheKey = a.id + ':' + counter;
      var code = state.codes[cacheKey];
      if (!code) {
        try {
          code = await T.totp(T.base32Decode(a.secret), now, { algorithm: a.algorithm, digits: a.digits, period: a.period });
        } catch (e) { code = 'ERROR'; }
        state.codes = {};                 // drop the previous counter: bounded memory
        state.codes[cacheKey] = code;
      }
      var left = T.secondsRemaining(now, a.period);
      var pct = Math.round(T.progress(now, a.period) * 100);
      var node = document.getElementById('otp-' + a.id);
      if (!node) {
        node = document.createElement('div');
        node.className = 'otp'; node.id = 'otp-' + a.id;
        node.innerHTML =
          '<div class="top"><span class="iss">' + esc(a.issuer || 'Unnamed issuer') + '</span>' +
          '<span class="acc">' + esc(a.account) + '</span></div>' +
          '<div class="code"><span class="grp"></span></div>' +
          '<div class="bar"><i></i></div>' +
          '<div class="meta"><span class="alg"></span><span class="left"></span><span class="sec"></span></div>' +
          '<div class="row" style="margin-top:8px"><button class="copy">Copy</button><button class="del danger ghost">Delete</button></div>';
        node.querySelector('.copy').addEventListener('click', function () { copyCode(a.id); });
        node.querySelector('.del').addEventListener('click', function () { del(a.id); });
        host.appendChild(node);
      }
      node.querySelector('.grp').textContent = group(code);
      node.querySelector('.code').className = 'code' + (left <= 5 ? ' expiring' : '');
      node.querySelector('.bar > i').style.width = pct + '%';
      node.querySelector('.alg').textContent = a.algorithm + ' · ' + a.digits + ' digits · ' + a.period + 's';
      node.querySelector('.left').textContent = left + 's left';
      node.querySelector('.sec').textContent = (a.notes || '');
    }
    // Remove rows for accounts that no longer exist / are filtered out.
    Array.prototype.forEach.call(host.querySelectorAll('.otp'), function (n) {
      var id = n.id.replace('otp-', '');
      if (!list.filter(function (a) { return a.id === id; }).length) n.remove();
    });
    el('header-code-count').textContent = list.length + ' code(s)';
  }

  function startTicker() {
    if (state.tick) clearInterval(state.tick);
    state.tick = setInterval(function () { renderCodes(); }, 500);
    renderCodes();
  }

  function copyCode(id) {
    var node = document.getElementById('otp-' + id);
    if (!node) return;
    var text = node.querySelector('.grp').textContent.replace(/\s+/g, '');
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () {
        trackOtpClipboard(text);
        toast('Code copied');
      }, function () { toast('Clipboard refused; the code was not copied'); });
    } else {
      toast('Clipboard unavailable; the code was not copied');
    }
  }

  function del(id) {
    var a = state.accounts.filter(function (x) { return x.id === id; })[0];
    if (!a) return;
    if (!window.confirm('Delete “' + (a.issuer || a.account) + '”? This removes the secret from the vault. There is no undo and no cloud copy.')) return;
    state.accounts = V.removeAccount(state.accounts, id);
    state.codes = {};
    save(); renderAccounts(); toast('Account deleted');
  }

  async function save() {
    if (!state.key) return false;
    try {
      var next = await V.save(state.env, state.accounts, state.key);
      if (!storeEnv(next)) return false;
      state.env = next;
      el('vault-count').textContent = state.accounts.length + ' account(s)';
      return true;
    } catch (e) {
      toast('could not save the vault: ' + (e && e.message ? e.message : e));
      return false;
    }
  }

  /* ---------------- add account ---------------- */

  function addFromForm() {
    var raw = {
      issuer: el('add-issuer').value, account: el('add-account').value, secret: el('add-secret').value,
      algorithm: el('add-alg').value, digits: Number(el('add-digits').value), period: Number(el('add-period').value)
    };
    var res = V.addAccount(state.accounts, raw);
    if (!res.ok) { el('add-error').textContent = 'Refused: ' + res.problems.join('; '); return; }
    state.accounts = res.accounts;
    el('add-error').textContent = '';
    ['add-issuer', 'add-account', 'add-secret'].forEach(function (i) { el(i).value = ''; });
    save().then(function (ok) {
      if (!ok) { el('add-error').textContent = 'Refused: the encrypted vault could not be saved.'; return; }
      renderAccounts(); toast('Account added');
    });
  }

  function addFromUri() {
    try {
      var p = T.parseOtpauth(el('add-uri').value);
      var res = V.addAccount(state.accounts, p);
      if (!res.ok) { el('uri-error').textContent = 'Refused: ' + res.problems.join('; '); return; }
      state.accounts = res.accounts;
      el('uri-error').textContent = ''; el('add-uri').value = '';
      save().then(function (ok) {
        if (!ok) { el('uri-error').textContent = 'Refused: the encrypted vault could not be saved.'; return; }
        renderAccounts(); toast('Imported ' + p.account);
      });
    } catch (e) {
      el('uri-error').textContent = 'Refused: ' + e.message;
    }
  }

  /* ---------------- QR enrollment (local only) ---------------- */
  var qr = { stream: null, raf: 0, active: false, pending: null };

  function qrNote(msg) { el('qr-note').textContent = msg || ''; }

  function stopQr(clearNote) {
    if (qr.raf) { cancelAnimationFrame(qr.raf); qr.raf = 0; }
    if (qr.stream) {
      qr.stream.getTracks().forEach(function (tr) { try { tr.stop(); } catch (e) {} });
      qr.stream = null;
    }
    var v = el('qr-video');
    if (v) { try { v.pause(); } catch (e) {} v.srcObject = null; v.hidden = true; }
    qr.active = false;
    if (clearNote) qrNote('');
  }

  function decodeImageSource(source, w, h, cb) {
    var c = el('qr-canvas');
    var scale = Math.min(1, 1000 / Math.max(w, h));
    c.width = Math.max(1, Math.round(w * scale));
    c.height = Math.max(1, Math.round(h * scale));
    var ctx = c.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(source, 0, 0, c.width, c.height);
    var data = ctx.getImageData(0, 0, c.width, c.height);
    if (typeof window.jsQR !== 'function') { cb('QR decoder unavailable in this build'); return; }
    var found = window.jsQR(data.data, data.width, data.height, { inversionAttempts: 'dontInvert' });
    cb(null, found && found.data ? found.data : null);
  }

  function qrPreview(payload) {
    var parsed;
    try { parsed = T.parseOtpauth(payload); }
    catch (e) { qrNote('Refused: ' + e.message); return false; }
    qr.pending = parsed;
    var text = (parsed.issuer || 'Unnamed issuer') + ' · ' + parsed.account +
      ' · ' + parsed.algorithm + ' · ' + parsed.digits + ' digits · ' + parsed.period + 's';
    el('qr-preview-text').textContent = text;
    el('qr-preview').style.display = 'block';
    qrNote('QR read. Confirm the account below; the secret is not shown.');
    return true;
  }

  function commitQrPreview() {
    if (!qr.pending) return;
    var parsed = qr.pending;
    var res = V.addAccount(state.accounts, parsed);
    if (!res.ok) { qrNote('Refused: ' + res.problems.join('; ')); return; }
    state.accounts = res.accounts;
    qr.pending = null;
    el('qr-preview').style.display = 'none';
    save().then(function (ok) {
      if (!ok) { qrNote('Refused: the encrypted vault could not be saved.'); return; }
      renderAccounts();
      toast('Imported ' + parsed.account);
    });
  }

  async function scanWithCamera() {
    stopQr(false);
    qrNote('');
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      qrNote('Camera capture is unavailable in this WebKit build. Import a QR image or use the URI/secret fields.');
      return;
    }
    try {
      qr.stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 640 }, height: { ideal: 640 } }, audio: false
      });
    } catch (e) {
      qrNote('Camera permission was not granted. Import a QR image or use the URI/secret fields.');
      return;
    }
    var v = el('qr-video');
    v.srcObject = qr.stream;
    v.hidden = false;
    try { await v.play(); } catch (e) { /* autoplay policy: the frame loop still runs */ }
    qr.active = true;
    var last = 0;
    var tick = function (ts) {
      if (!qr.active) return;
      if (ts - last >= 180 && v.videoWidth) {
        last = ts;
        decodeImageSource(v, v.videoWidth, v.videoHeight, function (err, payload) {
          if (err) { qrNote(err); stopQr(false); return; }
          if (payload) {
            stopQr(false);
            qrPreview(payload);
          }
        });
      }
      if (qr.active) qr.raf = requestAnimationFrame(tick);
    };
    qr.raf = requestAnimationFrame(tick);
  }

  function importQrImage(file) {
    if (!file) return;
    qrNote('');
    var img = new Image();
    var url = URL.createObjectURL(file);
    img.onload = function () {
      decodeImageSource(img, img.naturalWidth, img.naturalHeight, function (err, payload) {
        URL.revokeObjectURL(url);
        if (err) { qrNote(err); return; }
        if (!payload) { qrNote('No QR code was found in that image.'); return; }
        qrPreview(payload);
      });
    };
    img.onerror = function () { URL.revokeObjectURL(url); qrNote('That image could not be read.'); };
    img.src = url;
  }

  function renderAccounts() {
    el('vault-count').textContent = state.accounts.length + ' account(s)';
    renderCodes();
  }

  /* ---------------- import / export / maintenance ---------------- */

  function exportVault() {
    if (!state.env) return;
    var text = V.exportEnvelope(state.env);
    var blob = new Blob([text], { type: 'application/json' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'nuxel-authenticator-vault.json';
    document.body.appendChild(a); a.click(); a.remove();
    el('io-note').textContent = 'Exported the ENCRYPTED envelope (' + text.length + ' bytes). It is useless without the passphrase.';
  }

  function importVault() {
    var f = el('import-file').files[0];
    if (!f) { el('io-note').textContent = 'Choose a vault file first.'; return; }
    var fr = new FileReader();
    fr.onload = function () {
      try {
        var env = V.importEnvelope(String(fr.result));
        el('io-note').textContent = 'Envelope accepted (' + env.kdf.iterations + ' iterations). Enter its passphrase to unlock it.';
        state.env = env; state.key = null; state.accounts = [];
        storeEnv(env); renderLock();
        toast('Vault imported — unlock it with its passphrase');
      } catch (e) {
        el('io-note').textContent = e.message;
      }
    };
    fr.readAsText(f);
  }

  async function rekey() {
    var current = el('rk-current').value, next = el('rk-new').value, again = el('rk-new2').value;
    try {
      if (!state.key) throw new Error('unlock the vault first');
      var un = await V.unlock(state.env, current);
      if (next !== again) throw new Error('the new passphrases do not match');
      var policy = V.checkPassphrase(next);
      if (!policy.ok) throw new Error('new passphrase refused: ' + policy.problems.join(', '));
      // A new passphrase gets a FRESH salt and key: the envelope must carry the
      // matching KDF parameters or the vault would be unopenable afterwards.
      var created = await V.create(next);
      var newEnv = Object.assign({}, state.env, { kdf: created.envelope.kdf });
      var oldEnv = state.env, oldKey = state.key, oldAccounts = state.accounts;
      state.env = newEnv; state.key = created.key; state.accounts = un.accounts;
      var saved = await save();
      if (!saved) {
        state.env = oldEnv; state.key = oldKey; state.accounts = oldAccounts;
        throw new Error('the new encrypted envelope could not be saved; the old vault remains active');
      }
      var linkedNote = '';
      if (state.keyring.linked === true) {
        // The old credential belongs to the old passphrase.  Update it only
        // after the new envelope is durable; if that fails, remove it so the
        // app never auto-unlocks with a stale secret.
        var stored = await kr('authenticator-credential-store', { credential: next, consent: true });
        if (!stored.success) {
          await kr('authenticator-credential-delete');
          state.keyring.linked = false;
          linkedNote = ' Auto-unlock was disabled because the saved keyring credential could not be updated; re-link it in Security. The new passphrase opens the vault.';
        }
      }
      el('vault-kdf').textContent = state.env.kdf.name + '-' + state.env.kdf.hash + ' · ' + state.env.kdf.iterations + ' iterations';
      el('rk-note').textContent = 'Re-keyed with a fresh salt, key and AES-GCM IV. The old passphrase no longer opens this vault.' + linkedNote;
      ['rk-current', 'rk-new', 'rk-new2'].forEach(function (i) { el(i).value = ''; });
      await refreshKeyringState(false);
      toast('Vault re-keyed');
    } catch (e) { el('rk-note').textContent = e.message; }
    finally { current = null; next = null; again = null; }
  }

  async function wipe() {
    if (el('wipe-confirm').value.trim() !== 'DELETE AUTHENTICATOR VAULT') {
      el('wipe-note').textContent = 'Type DELETE AUTHENTICATOR VAULT exactly to confirm.';
      return;
    }
    var krNote = '';
    var cs = await kr('authenticator-credential-status');
    if (cs.success && cs.exists === true) {
      var del = await kr('authenticator-credential-delete');
      if (!del.success) {
        el('wipe-note').textContent = 'Cannot remove the saved Authenticator credential while the Nuxel Keyring is locked or unavailable. Unlock it and retry; the TOTP vault was NOT deleted.';
        return;
      }
      krNote = ' The saved Nuxel Keyring credential was removed.';
    } else if (cs.success && cs.exists === null) {
      el('wipe-note').textContent = 'The Nuxel Keyring is locked, so a saved credential cannot be removed. Unlock the keyring and retry; the TOTP vault was NOT deleted.';
      return;
    } else if (!cs.success) {
      el('wipe-note').textContent = 'Cannot confirm whether a saved keyring credential exists. Unlock the keyring and retry; the TOTP vault was NOT deleted.';
      return;
    }
    try { localStorage.removeItem(KEY); } catch (e) { /* ignore */ }
    stopKeyringPoll();
    clearOtpClipboardIfSame();
    state = {
      env: null, key: null, accounts: [], filter: '', tick: null, codes: {},
      keyring: { status: 'unknown', locked: null, linked: false, notInitialized: false,
                 autoBusy: false, poll: null },
      clip: null
    };
    el('codes').textContent = '';
    el('header-code-count').textContent = '';
    el('wipe-note').textContent = 'Authenticator vault deleted from this device. Nuxel Vault password items and unrelated keyring entries were not touched.' + krNote;
    renderLock(); toast('Authenticator vault deleted');
  }

  async function runSelfTest() {
    el('selftest-run').disabled = true;
    el('selftest-summary').textContent = 'running the RFC 6238 vectors…';
    el('selftest-summary').className = 'pill warn';
    var r = await V.selfTest();
    var rows = r.results.map(function (x) {
      return '<tr><td>' + esc(x.vector) + '</td><td>' + esc(x.expected) + '</td><td>' + esc(x.got) +
        '</td><td>' + (x.ok ? 'PASS' : 'FAIL') + '</td></tr>';
    }).join('');
    el('selftest-body').innerHTML = rows;
    el('selftest-summary').textContent = r.ok
      ? 'All ' + r.results.length + ' RFC 6238 vectors PASS — codes are computed by the same code path the list above uses.'
      : 'VECTOR FAILURE — do not trust codes from this build.';
    el('selftest-summary').className = 'pill ' + (r.ok ? 'ok' : 'bad');
    el('selftest-run').disabled = false;
  }

  /* ---------------- wiring ---------------- */

  // The sub-tabs only ever swap the four panels INSIDE #screen-main.  #screen-lock
  // and #screen-main are themselves .panel elements, so a global query here would
  // hide the whole app - hence the scoped selector.
  function tabs() {
    var root = el('screen-main');
    Array.prototype.forEach.call(root.querySelectorAll('.tab'), function (b) {
      b.addEventListener('click', function () {
        Array.prototype.forEach.call(root.querySelectorAll('.tab'), function (x) { x.classList.remove('active'); });
        Array.prototype.forEach.call(root.querySelectorAll('.panel'), function (x) { x.classList.remove('active'); });
        b.classList.add('active'); el('tab-' + b.dataset.tab).classList.add('active');
      });
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    tabs();
    el('lock-go').addEventListener('click', lockAction);
    el('pass').addEventListener('keydown', function (e) { if (e.key === 'Enter') lockAction(); });
    el('pass2').addEventListener('keydown', function (e) { if (e.key === 'Enter') lockAction(); });
    el('lock-now').addEventListener('click', function () { lockVault('manual'); });
    el('search').addEventListener('input', function () { state.filter = el('search').value; renderCodes(); });
    el('add-form-go').addEventListener('click', addFromForm);
    el('add-uri-go').addEventListener('click', addFromUri);
    el('export-go').addEventListener('click', exportVault);
    el('import-go').addEventListener('click', importVault);
    el('rekey-go').addEventListener('click', rekey);
    el('wipe-go').addEventListener('click', wipe);
    el('selftest-run').addEventListener('click', runSelfTest);
    el('qr-camera').addEventListener('click', scanWithCamera);
    el('qr-image-btn').addEventListener('click', function () { el('qr-image').click(); });
    el('qr-image').addEventListener('change', function (e) {
      var f = e.target.files && e.target.files[0];
      importQrImage(f);
      e.target.value = '';
    });
    el('qr-add').addEventListener('click', commitQrPreview);
    el('qr-cancel').addEventListener('click', function () {
      qr.pending = null; el('qr-preview').style.display = 'none'; qrNote('');
    });
    document.addEventListener('visibilitychange', function () {
      stopQr(false);
      // A backgrounded WebKit surface must never keep live OTP codes rendered.
      // Lock immediately on hide; an explicit foreground unlock is required.
      if (document.hidden && state.key) {
        lockVault('background');
      }
    });
    window.addEventListener('pagehide', function () { stopQr(false); lockVault(); });
    el('close').addEventListener('click', function () { try { window.close(); } catch (e) {} });
    el('selftest-summary').textContent = 'not run in this session';

    state.env = loadEnv();
    renderLock();
    refreshKeyringState(true);

    el('kr-unlock-go').addEventListener('click', keyringUnlockAction);
    el('kr-unlock-cancel').addEventListener('click', function () {
      el('kr-unlock-pass').value = '';
      el('kr-unlock-error').textContent = '';
      toast('Nuxel Keyring remains locked');
    });
    el('kr-unlock-pass').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') keyringUnlockAction();
    });
    el('kr-auto-go').addEventListener('click', autoUnlockFromKeyring);
    el('kr-link-go').addEventListener('click', linkKeyringCredential);
    el('kr-unlink').addEventListener('click', unlinkKeyringCredential);
    el('entra-start').addEventListener('click', function () {
      var target = el('qr-camera');
      if (target && target.scrollIntoView) target.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setTimeout(function () { try { target.focus(); } catch (e) {} }, 250);
    });
  });
}());
