# ROUND 02 — DeepSeek V4 Pro Thinking: repair the native NFC userspace path WITHOUT flashing

**Include `00_COMMON_MISSION_AND_NO_BRICK_CONTRACT.md` and the Round 01 baseline.** Work in a separate branch/worktree, **host tests only first**. No DT/BOOT/firmware/GPIO changes in this round. Reuse existing standard Linux `nfc` netlink and AF_NFC APIs; don't rewrite the whole daemon unless measurements prove that necessary.

## Required source fixes, with explicit negative tests

**Netlink framing and lifetime** (`services/nuxel-nfc/nuxel_nfc/kernel_nci.py`):
- Replace `_recv()`'s silent skip of `NLMSG_ERROR` with exact ACK/error parsing: ACK is `NLMSG_ERROR(errno=0)`, errors preserve `errno`/EXT_ACK if present, invalid/truncated frames and sequence/port mismatches fail closed, handle multiple nlmsghdrs per datagram, `NLMSG_DONE`, multipart dumps and timeouts. Tests must simulate success ACK-only, EPERM, ENODEV, EBUSY, EINVAL, malformed attr and mixed ACK+data. An empty data array is not itself a success or failure.
- Keep a **persistent bound AF_NETLINK/NETLINK_GENERIC command socket** from successful `START_POLL` through event handling, GET_TARGET, STOP_POLL and DEV_DOWN. The upstream NFC family tracks the requesting netlink portid and cancels polling on disconnect. Close only after STOP and cleanup. Verify the exact pinned 4.14 kernel implementation; use messages and per-request seq to avoid receiving unrelated events as ACKs. Subscribe to `NFC_EVENT_TARGETS_FOUND` only if confirmed supported; fallback bounded GET_TARGET dumps if not. Do not run a command per short-lived socket and call it polling. Implement cancellations and proper exception cleanup.
- Verify all numeric UAPI attributes/commands, `NFC_CMD_GET_DEVICE`, DEV_UP, START_POLL, GET_TARGET semantics against the **pinned** `include/uapi/linux/nfc.h` and `net/nfc/netlink.c`, not modern unverified constants. DUMP must gather all replies until DONE, not first message. Verify device index, protocol masks and raw socket target address packing.

**Controller type / scan flow** (`daemon.py`, `nci.py`, `kernel_nci.py`):
- Fix `_kernel_scan()`'s `nci.NciController(self.kernel).set_target(...)` call. `NciController` does not implement `set_target`; `KernelNci` does. Keep one clear transport interface and real target exchange; no fake activation or UID. Add a mock or fake that asserts `KernelNci.set_target` and raw transceive are reached, and a test that would have failed with the old code.
- Fix `clear()` dereferencing `self.transport.fd` when production `transport=None`. Differentiate `controller_present`, `device_up`, `poll_active`, `target_present`, `last_hardware_verified` in state/UI. Never claim `device_open` from a sysfs path or firmware hash.
- Make scan cancellation actually work while scan is active: non-blocking listener/worker design or a cancellable state machine, no daemon-wide lock held through the full wait, bounded timeout, safe stop/close on cancel/service restart. Add concurrent cancel test and 100 consecutive enable/disable test loops with mocks.

**Systemd + least privilege** (`services/nuxel-nfc/systemd/nuxel-nfcd.service`):
- Add **AF_NFC** to `RestrictAddressFamilies` for raw tag exchange while retaining AF_UNIX and AF_NETLINK. Test process behavior under actual sandbox and on actual pinned kernel. Audit whether `GENL_ADMIN_PERM` requires CAP_NET_ADMIN for `DEV_UP`/`START_POLL` on this kernel. If needed, isolate the smallest trusted operation behind a narrow broker (never grant web apps broad root/network-admin privileges). Check unit's `User=nuxel`, socket peer-UID contract, permission file read-only bind, and `DevicePolicy`. Do not simply run everything as root to bypass failures.

**Real authorization** (`policy.py`, bridge/provider):
- A pending/ask/expired/unknown capability record must **NOT** grant NFC. Repro from audit: `{ "nfc": {"decision":"ask", "granted":null} }` currently allowed. Require explicit affirmative, current grant with correct scope; deny beats allow, enforce expiry and per-app identity. Verify bridge cannot let a caller spoof `app_id`; do not trust a caller-supplied arbitrary app name. Test guest, missing, pending, expired, revoked, explicit deny, confirmed positive and power-only owner toggles.
- Read-only scope for this mission: disable `write`, `write-tag` and UI writing by policy, returning clear `READ_ONLY_NFC_MISSION`, regardless of confirmation/grants. No payment/eSE/card emulation. Default OFF; private data absent from logs/storage without owner consent.

## Offline test requirements

- Replace tests that just assert source strings with behavioral tests. Cover success/negative kernel netlink responses, multipart, socket close cancellations, AF_NFC target connect/reply, scanning state and cancellation, permission guard and hot restart. Run existing `tests/pwnage65000/test_nfc_service.py` and new netlink tests with no hardware; identify missing `.build` pinned headers honestly rather than pretending tests are green.
- Add an optional `--dry-run`/trace mode that never opens the physical controller and prints the intended operations, plus bounded event tracing with redacted UID/frames. No accidental hardware side effects from `selftest`.
- Preserve original bridge API and UI behavior unless fixing a real defect; run Python syntax, lint, tests and independent `nuxel-nfc selftest`.

**Output:** `reports/nfc/02-USERSPACE-FIXES.md`, committed source changes and tests, before/after failing test repros, sandbox + permissions contract, a reversible userspace deployment receipt/rollback script **but do NOT deploy anything that automatically starts NFC**. Mark all hardware still NOT_TESTED. **No flash.**
