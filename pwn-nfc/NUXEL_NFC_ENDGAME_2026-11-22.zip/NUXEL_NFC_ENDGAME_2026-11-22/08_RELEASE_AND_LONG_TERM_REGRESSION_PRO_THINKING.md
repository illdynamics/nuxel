# ROUND 08 — DeepSeek V4 Pro Thinking: productionize NFC with falsifiable PASS, safe rollout and recovery

**Attach common contract, source branch, all previous reports and actual tag results.** NFC release readiness is conditional on real physical PASS, never just a passing Python suite. Do **not** reflash in this round unless a new measured kernel defect was deliberately sent through Round 03/05/06 again.

1. Consolidate one NFC architecture: exclusive `7-0027` owner, correct Samsung driver or documented native vendor fallback, generic netlink persistent poll socket + PF_NFC, NDEF parser, daemon state and per-app permission path. Remove stale `/dev/nfc0` assertions as a required Linux NFC interface; status must clearly label *present* vs *powered* vs *NCI ready* vs *RF polling* vs *physical tag verified*.
2. Keep controller and tag writes, payments, HCE and eSE unsupported in the read-only release; tag content never automatically executes links, files, scripts or transactions. Default OFF; use bounded permissions, state cleanup, concurrency, cancel, crash/restart and suspend/resume. Verify no automatically scheduled firmware update or dangerous hash path. Verify source comments, config and UI honestly match behavior; remove contradictory `tag_writes_supported=True` advertisement.
3. Tests: existing NFC parser/transport mocks, new ACK/error/multipart netlink tests, real-API integration under service sandbox, negative privilege, no-tag timeouts, permission grant and spoof attempts, unit reload and data redaction; build/kernel image provenance and relevant S10+ health regressions. Test target's actual kernel code, not just current upstream. Report every skipped test as skipped with reason.
4. Source hygiene: document patch order, optional vs required policy, provenance, build hashes, current DTB/DTBO hash, flash/restore manifest and actual Nuxel boot; remove obsolete NFC `pwn/nfc` references or create accurate new continuation files as needed. Do not accidentally commit proprietary vendor binary from `evidence/live-20261114` to public Git. Keep a bootable golden recovery copy retained.
5. Update `README.md`, hardware compatibility matrix, changelog, current actual reports, `configs/nuxel/nfc/nfc.json`, diagnostics and tests. Add a simple operator playbook: how to test reader, view precise failure reason, disable NFC, and restore last-known-good BOOT if a future kernel update regresses.
6. Acceptance matrix per gate:
   - `G0_BOOT`: proven normal Nuxel cold/reboot and recovery safety, no SHA panic
   - `G1_BUS`: correct active driver, proven rail/clock/IRQ/valid physical controller exchange
   - `G2_NCI`: controller-origin CORE_RESET+INIT; valid ACK/error and live RF polling
   - `G3_RF`: two real owner tags; correct distinct UID and NDEF; 10 cycles
   - `G4_INTEGRATION`: permission/off state/UI/scan/cancel, restart, reboot/suspend, no regressions.
   Any gate not met = **PARTIAL/BLOCKED**, not a release PASS.
7. Produce one final artifact: `reports/NFC-ENDGAME-REAL-RF.md`, first-failure evidence (if any), exact change set/commits, URLs/commit of public source consulted, build/flash manifest, tests with live/mocks separated, resource ownership, known-good fallback SHA, and honest limitations. Do not publish sensitive logs or the OEM firmware.

**Finish criterion:** Real read-only NFC working via the physical antenna with reliable no-brick operating envelope. If proprietary limitations remain, use Round 09 and leave Nuxel healthy and NFC OFF instead of falsely claiming completion.
