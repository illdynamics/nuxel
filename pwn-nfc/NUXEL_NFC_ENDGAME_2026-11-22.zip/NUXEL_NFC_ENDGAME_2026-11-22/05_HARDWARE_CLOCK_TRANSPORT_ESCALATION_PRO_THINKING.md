# ROUND 05 — DeepSeek V4 Pro Thinking: S3NRN82 clock, bootloader↔NCI transition and first physical blocker

**Attach common contract + all preceding reports.** Execute this ONLY when read-only/limited Round 04 has proved a real physical NCI failure, or driver/NCI ownership cannot be established. This is one bounded hypothesis at a time, not a blanket 'fix the DT' instruction. No BOOT or DT flash in this round.

## Reconstruct board truth

A. On the exact running Exynos9820/S10+ board revision, map `/sys/bus/i2c/devices/7-0027` and DT to `sec-nfc@27`, VEN=188, FIRM=189, IRQ=10, clk_req=22 *only if live matches historical*; trace regulator `VDD_NFC_1P8`, `oscclk_nfc` parent/selector/enable/rate, clock-request IRQ edge and pinctrl active/sleep. Read Samsung `sec_nfc.c`, S3FWRN5 fork and actual clock driver. Compare native 26 MHz selection with vendor config, but do not infer 0 Hz means physical oscillator off without reliable measurement. NO guessed clock/phandle/hardcoded GPIO writes.

B. Capture a bounded power/clock/IRQ event trace, first in passive log/sysfs, then only with explicitly authorized minimal protocol reads when `G0 SAFE`. Distinguish: rail voltage/enable; clock gate requested versus actual; I²C ACK/write versus read; IRQ asserted versus drained; bootloader reply versus NCI response; controller in FIRM strap mode versus NCI. Handle bus/SDA/SCL timeout as STOP and controlled reset recovery, not 'try 20 retries'.

C. Decode one actual GET_BOOTINFO reply to 23-byte S3NRN82 layout, 4096-byte sector and 512-byte pages, compare expected 82.00.01.00 historically with current response. Verify per-packet parity bit, record lengths/endianness, mode latch timing and IRQ races. Confirm no unconditionally scheduled firmware SHA/download and no controller write. Reconcile `0007` vs `0021` mode transitions; prove exactly where CORE_RESET is lost.

D. Research exact matching Samsung downstream source and board vendor NFC userspace config (compatible firmware, `libnfc-sec-vendor.conf`, any RF/regulatory config) and Linux NFC generic netlink. Source-control identify URL, commit, board variant, license, ABI. Do **not** transplant S3NRN4V command selectors/firmware/RF calibration: it is different silicon. If proprietary firmware/signing or board calibration cannot be verified, do not 'make it work' by guessing bytes.

E. Decide the least risky path: (1) no kernel change if probe/NCI and netlink are now good; (2) minimal driver-only guard/fix; (3) narrowly scoped clock-mode handshake correction; (4) exclusive vendor `sec-nfc` NCI transport adapter if normal driver proven structurally incompatible; (5) **DT-only LAST RESORT** after independently proven wrong phandle/pinctrl/IRQ and validated safe rollback. Compare expected benefit, failure mode, verification and rescue. Avoid converting NCI compatibility uncertainty into a speculative board-wide DT rewrite.

F. If candidate kernel change necessary, produce a minimal signed-off diff, build/test plan, **known-good DT byte-for-byte preservation proof**, exact BOOT pack diff and a separate proposed reflash manifest with no write performed. Explicitly model whether any changes affect UFS/USB/SSP/camera, and show safe cleanup on NFC failure. Set a strict limited live probe budget. If no independent evidence for clock defect, keep DT untouched.

**Deliver:** `reports/nfc/05-FIRST-HARDWARE-BLOCKER.md`, raw redacted trace + interpretation, a source evidence table, branch decision (USERSpace_ONLY / DRIVER_ONLY / GUARDED_DT_LAST_RESORT / BLOCKED_VENDOR_FIRMWARE), and preflight for Round 06 only if essential. **No flash performed.**
